var class_e_vs___e_v3_color =
[
    [ "getVal", "class_e_vs___e_v3_color.html#ab6ae28df2698f352ce127920309fa3bf", null ],
    [ "init", "class_e_vs___e_v3_color.html#abcdaa258bbc2046cfcf88d561f8194f7", null ]
];