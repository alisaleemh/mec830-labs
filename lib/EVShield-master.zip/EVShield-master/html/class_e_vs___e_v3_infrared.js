var class_e_vs___e_v3_infrared =
[
    [ "init", "class_e_vs___e_v3_infrared.html#afe31e6e83a978c65ade722f625827ca1", null ],
    [ "readChannelButton", "class_e_vs___e_v3_infrared.html#a0f2a63402c6bd1e2361e706dfdd83318", null ],
    [ "readChannelHeading", "class_e_vs___e_v3_infrared.html#ab9c060084e2ab15a78e593d411e27031", null ],
    [ "readChannelProximity", "class_e_vs___e_v3_infrared.html#a9b9e3402b9b0a28afb61057043066071", null ],
    [ "readProximity", "class_e_vs___e_v3_infrared.html#a766623a579e6acc47cf303269e9b3a37", null ]
];