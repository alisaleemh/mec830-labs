var class_e_v_shield_i2_c =
[
    [ "EVShieldI2C", "class_e_v_shield_i2_c.html#ad8d334d52c0458db8daa2a55666755e3", null ],
    [ "checkAddress", "class_e_v_shield_i2_c.html#a0d9efb4ca44c84c7a978fc3400f26cb5", null ],
    [ "getDeviceID", "class_e_v_shield_i2_c.html#a01bb76c25b537fa20e1b665d2abe1fdb", null ],
    [ "getErrorCode", "class_e_v_shield_i2_c.html#a0aae44b9edb530685d92f45509f709e6", null ],
    [ "getFeatureSet", "class_e_v_shield_i2_c.html#afb45832f3bc65ef6199d26871afbbc87", null ],
    [ "getFirmwareVersion", "class_e_v_shield_i2_c.html#ab840df4178c2185e3754c5a63f2eafd9", null ],
    [ "getVendorID", "class_e_v_shield_i2_c.html#ae8284ef8911b27a117573be11c9de3ef", null ],
    [ "init", "class_e_v_shield_i2_c.html#a4e52d5923c11b593d63a6bbfe7d23632", null ],
    [ "readByte", "class_e_v_shield_i2_c.html#aebddba215ad02257256727432f8d6c52", null ],
    [ "readInteger", "class_e_v_shield_i2_c.html#ad1def2cb7dea12bb1cf6531d73e6d6a3", null ],
    [ "readLong", "class_e_v_shield_i2_c.html#abe642933c2cff670b3761af3e8577db2", null ],
    [ "readRegisters", "class_e_v_shield_i2_c.html#a43259908f1a8b39305cfea5022455a90", null ],
    [ "readString", "class_e_v_shield_i2_c.html#a8e6812209bba1d40a74b9363f2498ec4", null ],
    [ "setAddress", "class_e_v_shield_i2_c.html#a0e782cb7de9a64252dc7b11f17c6519a", null ],
    [ "writeByte", "class_e_v_shield_i2_c.html#aacefc55a3fc1cbea07b4f6049ec411d1", null ],
    [ "writeInteger", "class_e_v_shield_i2_c.html#a84faede3d1dc4b87a31ed41f56ba8cf7", null ],
    [ "writeLong", "class_e_v_shield_i2_c.html#aa5521a3eea046b7c1f6d9e3b7de33470", null ],
    [ "writeRegisters", "class_e_v_shield_i2_c.html#addbc8221e77952176e2026318e5c36a4", null ],
    [ "_i2c_buffer", "class_e_v_shield_i2_c.html#a8c584a33eda45ae2b6c44e367040584b", null ],
    [ "m_protocol", "class_e_v_shield_i2_c.html#a00cbb323f81b9756c278ea734604e233", null ],
    [ "mp_shield", "class_e_v_shield_i2_c.html#a623b1fa3636c5f6630f82ca1091f6ae9", null ]
];