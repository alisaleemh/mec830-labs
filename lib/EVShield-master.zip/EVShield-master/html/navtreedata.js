var NAVTREE =
[
  [ "EVShield", "index.html", [
    [ "EVShield Library Reference", "index.html", [
      [ "Introduction", "index.html#intro_sec", null ],
      [ "Getting Started", "index.html#getting_started", null ],
      [ "More Information", "index.html#more_info", null ],
      [ "Installation Instructions", "index.html#install_sec", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_base_i2_c_device_8h_source.html",
"class_e_v_shield_i2_c.html#a0aae44b9edb530685d92f45509f709e6",
"class_e_vs___p_f_mate.html#adab606da4f300960b4c2d29e0f4185c8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';