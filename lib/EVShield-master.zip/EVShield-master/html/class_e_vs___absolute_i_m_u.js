var class_e_vs___absolute_i_m_u =
[
    [ "EVs_AbsoluteIMU", "class_e_vs___absolute_i_m_u.html#a32c8c421886f7910ba3ee235aaf41f00", null ],
    [ "beginCompassCalibration", "class_e_vs___absolute_i_m_u.html#ada5ecacef2e38e95a0fe3cd1f47486ee", null ],
    [ "endCompassCalibration", "class_e_vs___absolute_i_m_u.html#a1ebca36af4f238561032e178968c377c", null ],
    [ "issueCommand", "class_e_vs___absolute_i_m_u.html#a79fae749fad6df0e8df7a4c07227574b", null ],
    [ "readAccelerometer", "class_e_vs___absolute_i_m_u.html#afd7d0cc3144ca8e298d243704661c8cf", null ],
    [ "readCompass", "class_e_vs___absolute_i_m_u.html#a17244ab1f6414c78bd5158b8e60fd25a", null ],
    [ "readGyro", "class_e_vs___absolute_i_m_u.html#ac9d08d4dbf62dfcc465b8423290cffc2", null ],
    [ "readMagneticField", "class_e_vs___absolute_i_m_u.html#a4a7eedefe6f8a786f9e6fa86dc3f7662", null ]
];