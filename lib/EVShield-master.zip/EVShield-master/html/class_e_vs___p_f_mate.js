var class_e_vs___p_f_mate =
[
    [ "EVs_PFMate", "class_e_vs___p_f_mate.html#a51ca2413ea1fee3958061c1eb87ed5e2", null ],
    [ "controlMotor", "class_e_vs___p_f_mate.html#a6b3801954159c05506b082d3e1264224", null ],
    [ "issueCommand", "class_e_vs___p_f_mate.html#a602494f8115f3f54be3b0fd5436dee9b", null ],
    [ "sendSignal", "class_e_vs___p_f_mate.html#a247951c4e3e8f59344c0aa56fd3eb94a", null ],
    [ "setChannel", "class_e_vs___p_f_mate.html#a7c18a4167d9641daecbe245d9851926a", null ],
    [ "setControl", "class_e_vs___p_f_mate.html#a6d608f73e17f7baedfd29ec71cb7aa0d", null ],
    [ "setOperationA", "class_e_vs___p_f_mate.html#adab606da4f300960b4c2d29e0f4185c8", null ],
    [ "setOperationB", "class_e_vs___p_f_mate.html#af8924c7a534df5f896183e9b3042e03e", null ],
    [ "setSpeedA", "class_e_vs___p_f_mate.html#a3b24aa7dc32894cc770214694cf0407c", null ],
    [ "setSpeedB", "class_e_vs___p_f_mate.html#a692f3f3af0d38e744d4a4263be7927d1", null ]
];