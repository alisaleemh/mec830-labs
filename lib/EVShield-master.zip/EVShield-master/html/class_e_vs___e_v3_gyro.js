var class_e_vs___e_v3_gyro =
[
    [ "getAngle", "class_e_vs___e_v3_gyro.html#abf015ec0446a5b387488347de1a81da3", null ],
    [ "getRefAngle", "class_e_vs___e_v3_gyro.html#aec96379abb38042a44fcb7ec0439b583", null ],
    [ "init", "class_e_vs___e_v3_gyro.html#ac0280ccd5e00cb66f741553381118987", null ],
    [ "setRef", "class_e_vs___e_v3_gyro.html#a8b9bbd0edd4cfaa5f5bebe921bd97950", null ]
];