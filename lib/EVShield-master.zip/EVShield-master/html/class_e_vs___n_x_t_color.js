var class_e_vs___n_x_t_color =
[
    [ "EVs_NXTColor", "class_e_vs___n_x_t_color.html#ac5fcdd8ad554c757f690471d193a19d2", null ],
    [ "EVs_NXTColor", "class_e_vs___n_x_t_color.html#a3c8e2c6d1c6e4f7f9288599b904a42f7", null ],
    [ "init", "class_e_vs___n_x_t_color.html#a6de7b2aa93f12c530d98682bffadc2fc", null ],
    [ "readColor", "class_e_vs___n_x_t_color.html#a4d906fbbc4491047bdb1d2be33a694d7", null ],
    [ "readValue", "class_e_vs___n_x_t_color.html#a02d02da4e8b8efa395b3a11672db4338", null ],
    [ "setType", "class_e_vs___n_x_t_color.html#a80d7b140edabae6e28f1f90bad5412b6", null ],
    [ "m_bp", "class_e_vs___n_x_t_color.html#ab34dffd1adcf5d5927af77eb05817aa6", null ],
    [ "m_offset", "class_e_vs___n_x_t_color.html#a56694c134627e81c05e20a79cb278d98", null ],
    [ "mp_shield", "class_e_vs___n_x_t_color.html#aeec6cf64ecfdaf9b0743afa5e3e6ba64", null ]
];