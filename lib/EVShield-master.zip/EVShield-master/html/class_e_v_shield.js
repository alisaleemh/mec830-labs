var class_e_v_shield =
[
    [ "EVShield", "class_e_v_shield.html#a000222aa9a91c04a3b44ce1649c6356e", null ],
    [ "checkButton", "class_e_v_shield.html#ab208ffdb321c851feb69bf92af603783", null ],
    [ "getButtonState", "class_e_v_shield.html#ab68a1603b8a32c5b6717890355c01c0e", null ],
    [ "getFunctionButton", "class_e_v_shield.html#ac0b5f7d32e5ceb224ebc92df78297c04", null ],
    [ "getTouchscreenValues", "class_e_v_shield.html#a1935f6cacf2e7589eb29939707350c03", null ],
    [ "I2CTimer", "class_e_v_shield.html#a8e9804965486516804ec8e34350edfa6", null ],
    [ "init", "class_e_v_shield.html#a5d3be5e588e0a84f2809a1ac07a5a8b6", null ],
    [ "initLEDTimers", "class_e_v_shield.html#a3a5e2906bd411eb1b1f5a9d968d7de39", null ],
    [ "initProtocols", "class_e_v_shield.html#a20e1f0c5ca58e2000949a15101259abd", null ],
    [ "isTouched", "class_e_v_shield.html#a2dab2c52bb6151ec4cf6b084528f5aa1", null ],
    [ "ledBreathingPattern", "class_e_v_shield.html#a052e8639e594c1601b5351b273fe20f1", null ],
    [ "ledHeartBeatPattern", "class_e_v_shield.html#a447869699a5b7d2a2f0c3e4b5fdad26f", null ],
    [ "ledSetRGB", "class_e_v_shield.html#af3a1e13c869f6519e677ca4b5e9809a6", null ],
    [ "TS_X", "class_e_v_shield.html#a9769717dec0052b87b279bfc95669d6b", null ],
    [ "TS_Y", "class_e_v_shield.html#a3f5f63449cc0c2be3c82af432a6e4269", null ],
    [ "waitForButtonPress", "class_e_v_shield.html#a91b5f4b91d6b2c2a16b18cf4e5acf67f", null ],
    [ "bank_a", "class_e_v_shield.html#afe3be42f832df2caed811d3f0f5c730a", null ],
    [ "bank_b", "class_e_v_shield.html#a3609601fe9bff117c01cc97ea9b3d11f", null ],
    [ "m_protocol", "class_e_v_shield.html#ad7a310143b78a0c615f278fc979a29da", null ]
];