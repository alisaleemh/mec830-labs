var searchData=
[
  ['deenergize',['deEnergize',['../class_e_vs___d_i_s_t_nx.html#a3b0557c33c9f2bc65e2146c1e9dc5334',1,'EVs_DISTNx::deEnergize()'],['../class_e_vs___p_s_p_nx.html#a8f00bdb01ca7e9bb52083e03a8ee360d',1,'EVs_PSPNx::deEnergize()']]],
  ['detect',['detect',['../class_e_vs___e_v3_ultrasonic.html#ae61d33a289276143eb965843a9253336',1,'EVs_EV3Ultrasonic']]],
  ['detectobstaclezone',['detectObstacleZone',['../class_e_vs___sumo_eyes.html#a3c1467b2446e1fd1e97e378931d3e05a',1,'EVs_SumoEyes']]],
  ['disabletracking',['disableTracking',['../class_e_vs___n_x_t_cam.html#ad5ea1ffeb0bbb280523a1d0519f95530',1,'EVs_NXTCam']]]
];
