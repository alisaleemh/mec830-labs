var searchData=
[
  ['b',['b',['../structcolor.html#a54c0fe3a59d6f43a47d365c545de1693',1,'color']]],
  ['bank_5fa',['bank_a',['../class_e_v_shield.html#afe3be42f832df2caed811d3f0f5c730a',1,'EVShield']]],
  ['bank_5fb',['bank_b',['../class_e_v_shield.html#a3609601fe9bff117c01cc97ea9b3d11f',1,'EVShield']]],
  ['basei2cdevice',['BaseI2CDevice',['../class_base_i2_c_device.html',1,'BaseI2CDevice'],['../class_base_i2_c_device.html#a62f63fa5bcbea73b209d44c70ae1def3',1,'BaseI2CDevice::BaseI2CDevice()']]],
  ['begincompasscalibration',['beginCompassCalibration',['../class_e_vs___absolute_i_m_u.html#ada5ecacef2e38e95a0fe3cd1f47486ee',1,'EVs_AbsoluteIMU']]]
];
