var searchData=
[
  ['magnetic_5ffield',['magnetic_field',['../structmagnetic__field.html',1,'']]]
];
