var searchData=
[
  ['nxshieldgetbatteryvoltage',['nxshieldGetBatteryVoltage',['../class_e_v_shield_bank.html#ae847eadc336ddb1ae208038564d65064',1,'EVShieldBank']]]
];
