var searchData=
[
  ['takesnapshot',['takeSnapshot',['../class_e_vs___line_leader.html#a1567cef4ce6db5161de66914fd4c0331',1,'EVs_LineLeader']]],
  ['ts_5fx',['TS_X',['../class_e_v_shield.html#a9769717dec0052b87b279bfc95669d6b',1,'EVShield']]],
  ['ts_5fy',['TS_Y',['../class_e_v_shield.html#a3f5f63449cc0c2be3c82af432a6e4269',1,'EVShield']]]
];
