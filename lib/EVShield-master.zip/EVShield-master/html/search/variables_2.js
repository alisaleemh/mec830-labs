var searchData=
[
  ['b',['b',['../structcolor.html#a54c0fe3a59d6f43a47d365c545de1693',1,'color']]],
  ['bank_5fa',['bank_a',['../class_e_v_shield.html#afe3be42f832df2caed811d3f0f5c730a',1,'EVShield']]],
  ['bank_5fb',['bank_b',['../class_e_v_shield.html#a3609601fe9bff117c01cc97ea9b3d11f',1,'EVShield']]]
];
