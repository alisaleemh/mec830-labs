var class_e_vs___sumo_eyes =
[
    [ "detectObstacleZone", "class_e_vs___sumo_eyes.html#a3c1467b2446e1fd1e97e378931d3e05a", null ],
    [ "init", "class_e_vs___sumo_eyes.html#aa6d4d555b651984c898cb9e37b3b642e", null ],
    [ "OBZoneToString", "class_e_vs___sumo_eyes.html#a7da5a0bf3eb529ea8f26237e22964a2c", null ],
    [ "setLongRange", "class_e_vs___sumo_eyes.html#ab1b5fcd60f8be78228159c2f87ead375", null ],
    [ "setShortRange", "class_e_vs___sumo_eyes.html#a462ff88cd8ae25b4a0b4b969e90f0b8c", null ],
    [ "setType", "class_e_vs___sumo_eyes.html#ae1c5ab83d4986d398ad973bbeff7d4cf", null ]
];