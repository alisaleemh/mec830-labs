var class_base_i2_c_device =
[
    [ "BaseI2CDevice", "class_base_i2_c_device.html#a62f63fa5bcbea73b209d44c70ae1def3", null ],
    [ "checkAddress", "class_base_i2_c_device.html#a6f47145afd71007190cf44383abcc8ae", null ],
    [ "getAddress", "class_base_i2_c_device.html#aa282bb683e22262748497ed1ae433e15", null ],
    [ "getDeviceID", "class_base_i2_c_device.html#a05ff39442c78410f4bdaf5c7c3fb8340", null ],
    [ "getFeatureSet", "class_base_i2_c_device.html#a132997ab07e64603dce91883fc501d3c", null ],
    [ "getFirmwareVersion", "class_base_i2_c_device.html#a78ea4709eb2d59cdceb02fa1fee175c7", null ],
    [ "getVendorID", "class_base_i2_c_device.html#ab21b79094ec9841e0cb43bb67609c51f", null ],
    [ "getWriteErrorCode", "class_base_i2_c_device.html#ae0bb486dda6232cc3bd4e7b95521af95", null ],
    [ "initProtocol", "class_base_i2_c_device.html#acc95ab6f1986f38403daead419e316ac", null ],
    [ "readByte", "class_base_i2_c_device.html#a427f3ff65f3bed8d26e6697397a16132", null ],
    [ "readInteger", "class_base_i2_c_device.html#ac1c36cb13ead55f0a2b76b959e76aa5a", null ],
    [ "readLong", "class_base_i2_c_device.html#aef9ddea43fc84deb005f794b80ecf232", null ],
    [ "readRegisters", "class_base_i2_c_device.html#abb9bad3def0eebbc54b05738e5da8823", null ],
    [ "readString", "class_base_i2_c_device.html#a462c3c8ff525fdf274953318f8b4ab6d", null ],
    [ "setAddress", "class_base_i2_c_device.html#abd6f0e41391e8a232913d12cec872615", null ],
    [ "setWriteErrorCode", "class_base_i2_c_device.html#a71a6513f582b2c7974e41001996cc78d", null ],
    [ "writeByte", "class_base_i2_c_device.html#a8058ca5d0986f71307bc36c40832d25d", null ],
    [ "writeInteger", "class_base_i2_c_device.html#a5ff01e20693bcfc4684460fc6b29ae72", null ],
    [ "writeLong", "class_base_i2_c_device.html#abcfea2377442933e1e6a46f072ee08f7", null ],
    [ "writeRegisters", "class_base_i2_c_device.html#ae57180c78fa931acc5be5683717e6534", null ]
];