var class_e_vs___d_i_s_t_nx =
[
    [ "EVs_DISTNx", "class_e_vs___d_i_s_t_nx.html#aed6d1c464190d1341a0c3f5c638acefe", null ],
    [ "deEnergize", "class_e_vs___d_i_s_t_nx.html#a3b0557c33c9f2bc65e2146c1e9dc5334", null ],
    [ "energize", "class_e_vs___d_i_s_t_nx.html#aa3564416846550ef99d3d7952d156cb5", null ],
    [ "getDist", "class_e_vs___d_i_s_t_nx.html#a9ef329ef592ed78757e38a9588ec7685", null ],
    [ "getType", "class_e_vs___d_i_s_t_nx.html#a782e008c817d83c0014ff12b66d7c1df", null ],
    [ "getVolt", "class_e_vs___d_i_s_t_nx.html#acd232735706600df747f030bed5b18ab", null ],
    [ "issueCommand", "class_e_vs___d_i_s_t_nx.html#ab50d1fd75b92734f916925d1e7fc460a", null ]
];