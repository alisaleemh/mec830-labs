var class_e_vs___n_x_t_touch =
[
    [ "init", "class_e_vs___n_x_t_touch.html#ad9e15235193cc4dcca1019f7ac83c2e5", null ],
    [ "isPressed", "class_e_vs___n_x_t_touch.html#ad181b1de0ca51b1c0e33a848a45185e5", null ]
];