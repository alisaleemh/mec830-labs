var class_e_vs___e_v3_touch =
[
    [ "getBumpCount", "class_e_vs___e_v3_touch.html#a8cf92835871b38179de9f22e71a33de3", null ],
    [ "init", "class_e_vs___e_v3_touch.html#ab0dbec05f93f8b6f41334d2deccea791", null ],
    [ "isPressed", "class_e_vs___e_v3_touch.html#a47f395a5be2f6f035b218debee9d897a", null ],
    [ "resetBumpCount", "class_e_vs___e_v3_touch.html#a5446f7a2b3ee56ecb262a0542f5eab7b", null ]
];