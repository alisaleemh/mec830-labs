var class_e_vs___light_sensor_array =
[
    [ "EVs_LightSensorArray", "class_e_vs___light_sensor_array.html#abd2afef149cf173f79bde3fea3d468be", null ],
    [ "calibrateBlack", "class_e_vs___light_sensor_array.html#a5a61a2b4d49dd1f2319dc4ca5d9ecc40", null ],
    [ "calibrateWhite", "class_e_vs___light_sensor_array.html#a999f2078bca8de618989e9d7a6aa5453", null ],
    [ "configureEurope", "class_e_vs___light_sensor_array.html#aca5259538afc1390f9f3667a60cb5182", null ],
    [ "configureUniversal", "class_e_vs___light_sensor_array.html#ae9c2078df787358fc348a741ea0abf63", null ],
    [ "configureUS", "class_e_vs___light_sensor_array.html#aaa496158deea8bd1a4979300a5bf61f5", null ],
    [ "getBlackCalibration", "class_e_vs___light_sensor_array.html#ab36c3fbb7f93d28e8c7b9326f10adc0a", null ],
    [ "getBlackLimit", "class_e_vs___light_sensor_array.html#a754a2c0e0b92e4d7ebd5339ac5d51595", null ],
    [ "getCalibrated", "class_e_vs___light_sensor_array.html#aa1f467c8b704726dca52505770df636a", null ],
    [ "getUncalibrated", "class_e_vs___light_sensor_array.html#ad3619b6f5b9acbd5cfaf38704ca5b364", null ],
    [ "getWhiteCalibration", "class_e_vs___light_sensor_array.html#a1c7b4d2a180b0578da5bb7a6a113a990", null ],
    [ "getWhiteLimit", "class_e_vs___light_sensor_array.html#ac0ef2ebbd22f0317f0e40d047e0dc92d", null ],
    [ "issueCommand", "class_e_vs___light_sensor_array.html#ae2f33fc4d08ccc3785d08a444cea3393", null ],
    [ "sleep", "class_e_vs___light_sensor_array.html#a7f2cb40bf99a871070fec6f64527d25f", null ],
    [ "wakeUp", "class_e_vs___light_sensor_array.html#a98b2d41e55d41c971c4a1a9c646048e2", null ]
];