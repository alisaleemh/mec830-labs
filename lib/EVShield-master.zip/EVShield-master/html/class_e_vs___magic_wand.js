var class_e_vs___magic_wand =
[
    [ "EVs_MagicWand", "class_e_vs___magic_wand.html#a7a6967a2dfab86b8688eef028937f874", null ],
    [ "lightWand", "class_e_vs___magic_wand.html#ace4bac0ea88db1efd97f85ad8d9a86e5", null ]
];