var class_e_vs___n_x_t_light =
[
    [ "init", "class_e_vs___n_x_t_light.html#a99471c0dfe5d9576898ce7e555cfb6eb", null ],
    [ "setAmbient", "class_e_vs___n_x_t_light.html#a31217ed4911d1f5acf8446c110400a36", null ],
    [ "setReflected", "class_e_vs___n_x_t_light.html#a3dc2f6b839e5d5d62c1958bc0f45df27", null ]
];