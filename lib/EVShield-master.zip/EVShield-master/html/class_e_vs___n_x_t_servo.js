var class_e_vs___n_x_t_servo =
[
    [ "EVs_NXTServo", "class_e_vs___n_x_t_servo.html#ab083aa7404bef94a0f2ee0a7aa1aa313", null ],
    [ "editMacro", "class_e_vs___n_x_t_servo.html#a0c04b79441cde46854b9f93ca214d699", null ],
    [ "getBatteryVoltage", "class_e_vs___n_x_t_servo.html#ace1e39ba825a1903b34eab23780f65fc", null ],
    [ "gotoEEPROM", "class_e_vs___n_x_t_servo.html#ae1d0c2c79838a2e562ddfe77636148fb", null ],
    [ "haltMacro", "class_e_vs___n_x_t_servo.html#a9473d6091eaa3ac25da5325363bd1674", null ],
    [ "issueCommand", "class_e_vs___n_x_t_servo.html#ac1ad10ba093e838627df53070a26255f", null ],
    [ "pauseMacro", "class_e_vs___n_x_t_servo.html#a24818e5eda8bd0089e087d57f900c48d", null ],
    [ "reset", "class_e_vs___n_x_t_servo.html#a7681e5a2b7e4ea7ed1c74e6038cfc8fb", null ],
    [ "resumeMacro", "class_e_vs___n_x_t_servo.html#a6bbe55318077bf1eadf6cbab49ac1490", null ],
    [ "runServo", "class_e_vs___n_x_t_servo.html#af50b793e356b6c3c9614250803ffd783", null ],
    [ "setPosition", "class_e_vs___n_x_t_servo.html#a757af892cc56fb483a842b51ff11d782", null ],
    [ "setSpeed", "class_e_vs___n_x_t_servo.html#a05932335c65899a40c1d75c7fda3a319", null ],
    [ "storeInitial", "class_e_vs___n_x_t_servo.html#a8a6e2e38e8c5907033bddafb43b45da6", null ]
];