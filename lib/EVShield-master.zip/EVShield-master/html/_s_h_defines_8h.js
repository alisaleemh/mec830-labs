var _s_h_defines_8h =
[
    [ "BTN_GO", "_s_h_defines_8h.html#afe7569574e3d736dbfb837ef409c513a", null ],
    [ "BTN_LEFT", "_s_h_defines_8h.html#a7881c76074b0ea36507f46b36840f54b", null ],
    [ "BTN_RIGHT", "_s_h_defines_8h.html#aeb8b29caaae1a7515c8bd9473e6eefb1", null ],
    [ "LED_BLUE", "_s_h_defines_8h.html#ae2e40566d27689f8581d7b0f12271d45", null ],
    [ "LED_GREEN", "_s_h_defines_8h.html#aca338dbd19d7940923334629f6e5f3b7", null ],
    [ "LED_RED", "_s_h_defines_8h.html#a31e20330f8ce94e0dd10b005a15c5898", null ],
    [ "SCL_BAS1", "_s_h_defines_8h.html#aeb8a1089ff882089110dccd1ad088e69", null ],
    [ "SCL_BAS2", "_s_h_defines_8h.html#a753104eb2f6c75edfb045b56c081d6fc", null ],
    [ "SCL_BBS1", "_s_h_defines_8h.html#a776584d3cdeb51c142eea9e9e6a55340", null ],
    [ "SCL_BBS2", "_s_h_defines_8h.html#a469fa43f94011d26e0cd3985f99d762d", null ],
    [ "SDA_BAS1", "_s_h_defines_8h.html#ac8b1b66fb2a336988961a90ba215a690", null ],
    [ "SDA_BAS2", "_s_h_defines_8h.html#a232b8c99b404634127b5b3d808ae1798", null ],
    [ "SDA_BBS1", "_s_h_defines_8h.html#acf7e81a02ea5c79b5053cc71e30238eb", null ],
    [ "SDA_BBS2", "_s_h_defines_8h.html#ae5d9ab06266968850ff74d4ef2d22f56", null ],
    [ "SH_BankPort", "_s_h_defines_8h.html#a31de44930af0260d3d96576c39e5bc12", [
      [ "SH_BAS1", "_s_h_defines_8h.html#a31de44930af0260d3d96576c39e5bc12af49da03f953fc6c8da964dd535be91ba", null ],
      [ "SH_BAS2", "_s_h_defines_8h.html#a31de44930af0260d3d96576c39e5bc12ab55deab5f7352c6c1b97834323de0a06", null ],
      [ "SH_BBS1", "_s_h_defines_8h.html#a31de44930af0260d3d96576c39e5bc12aeb892f6256a2501d7d0c61a3f9e7e35f", null ],
      [ "SH_BBS2", "_s_h_defines_8h.html#a31de44930af0260d3d96576c39e5bc12a52279ed0e67ff0fc8e0390de2f7c2c46", null ]
    ] ],
    [ "SH_Protocols", "_s_h_defines_8h.html#a981015d84d9e58975ebbb9cf83bbac75", [
      [ "SH_HardwareI2C", "_s_h_defines_8h.html#a981015d84d9e58975ebbb9cf83bbac75a8acfa7e97ceb22441cee34790b2820bd", null ],
      [ "SH_SoftwareI2C", "_s_h_defines_8h.html#a981015d84d9e58975ebbb9cf83bbac75a6b3c8be1e881a6125fd9e192b91003d2", null ]
    ] ]
];