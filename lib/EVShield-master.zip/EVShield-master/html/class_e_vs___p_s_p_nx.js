var class_e_vs___p_s_p_nx =
[
    [ "EVs_PSPNx", "class_e_vs___p_s_p_nx.html#a8e46dd537931cc027d6aab520f57790b", null ],
    [ "deEnergize", "class_e_vs___p_s_p_nx.html#a8f00bdb01ca7e9bb52083e03a8ee360d", null ],
    [ "energize", "class_e_vs___p_s_p_nx.html#a572af683fe30b610e1b1e0f07d67888a", null ],
    [ "getButtons", "class_e_vs___p_s_p_nx.html#a3b8de6c620cb170828ce7e20626ffa3d", null ],
    [ "getXLJoy", "class_e_vs___p_s_p_nx.html#a599123f9fae35c23bca151dd571f2211", null ],
    [ "getXRJoy", "class_e_vs___p_s_p_nx.html#a43c5a1236b7336928244bba9e509b374", null ],
    [ "getYLJoy", "class_e_vs___p_s_p_nx.html#aa69f498a21023bb0aeb5628fa3f09767", null ],
    [ "getYRJoy", "class_e_vs___p_s_p_nx.html#afa304b80a39d3e93e192a46247cdcac1", null ],
    [ "issueCommand", "class_e_vs___p_s_p_nx.html#a33772ecfbb4903fb5ca63cf75d572342", null ],
    [ "setAnalogMode", "class_e_vs___p_s_p_nx.html#aa5fee8ab25a656dee53aa620bf645b99", null ],
    [ "setDigitalMode", "class_e_vs___p_s_p_nx.html#a8e8285ef5635503b8caae12e2ac8d0cf", null ]
];