var class_e_vs___r_t_c =
[
    [ "EVs_RTC", "class_e_vs___r_t_c.html#a1e683c4d0d9d6d0027feb6981191fc2e", null ],
    [ "getDayMonth", "class_e_vs___r_t_c.html#a9f97b7025ad74dda5e801159533dec0c", null ],
    [ "getDayWeek", "class_e_vs___r_t_c.html#a84673518308a5d6d247a6bd22679a0c1", null ],
    [ "getHours", "class_e_vs___r_t_c.html#ae3810e1a309e7bccb0e0d8a55fb65d29", null ],
    [ "getMinutes", "class_e_vs___r_t_c.html#a3b99652d2ca334fd89d49c447287d175", null ],
    [ "getMonth", "class_e_vs___r_t_c.html#aea502a02fc4e559ab00efeacecf2ea38", null ],
    [ "getSeconds", "class_e_vs___r_t_c.html#abb65e0d41884aa6af64c8577a8951e33", null ],
    [ "getYear", "class_e_vs___r_t_c.html#a384a496dece9ae7b7920b44f84c35c42", null ]
];