var class_e_vs___angle_sensor =
[
    [ "EVs_AngleSensor", "class_e_vs___angle_sensor.html#a8cb3459b4a28d7f1360a90804dbb1e4b", null ],
    [ "getAngle", "class_e_vs___angle_sensor.html#ad51376f4404cf784a6130ab93cc86404", null ],
    [ "getRawReading", "class_e_vs___angle_sensor.html#a48602ec9b9970a7521189924311e0338", null ],
    [ "issueCommand", "class_e_vs___angle_sensor.html#a2ee7d5f99ff8d4ec8cdbeb39a69a2bae", null ],
    [ "reset", "class_e_vs___angle_sensor.html#a2acde0c2ad2f19207c52001e8161005c", null ]
];