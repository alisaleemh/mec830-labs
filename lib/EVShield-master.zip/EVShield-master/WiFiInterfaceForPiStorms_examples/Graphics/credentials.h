#ifndef MS_CREDENTIALS
#define MS_CREDENTIALS

// used for uploading OTA (over the air)
const char* SSID     = "pistormsclassroom";
const char* PASSWORD = "pistormsclassroom";
const char* UPLOAD_PASSWORD = "";

#endif
